import os
import numpy as np
import pandas as pd

np.random.seed(42)

path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                    "WA_Fn-UseC_-Telco-Customer-Churn.csv")
df = pd.read_csv(path)

df = df.drop(columns=["customerID"])
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df = df.dropna()

y = (df["Churn"] == "Yes").astype(float).values
X = df.drop(columns=["Churn"])
X = pd.get_dummies(X, drop_first=True).astype(float).values

idx = np.random.permutation(len(X))
split = int(0.8 * len(X))
X_train, y_train = X[idx[:split]], y[idx[:split]]
X_test, y_test = X[idx[split:]], y[idx[split:]]

mean, std = X_train.mean(axis=0), X_train.std(axis=0)
std[std == 0] = 1
X_train = (X_train - mean) / std
X_test = (X_test - mean) / std

X_train = np.hstack([np.ones((len(X_train), 1)), X_train])
X_test = np.hstack([np.ones((len(X_test), 1)), X_test])


def sigmoid(z):
    return 1 / (1 + np.exp(-np.clip(z, -500, 500)))


def loss_fn(y, p):
    p = np.clip(p, 1e-12, 1 - 1e-12)
    return -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))


def gradient(X, y, w):
    p = sigmoid(X @ w)
    return X.T @ (p - y) / len(y)


def metrics(y, p):
    pred = (p >= 0.5).astype(int)
    tp = np.sum((pred == 1) & (y == 1))
    tn = np.sum((pred == 0) & (y == 0))
    fp = np.sum((pred == 1) & (y == 0))
    fn = np.sum((pred == 0) & (y == 1))

    accuracy = (tp + tn) / len(y)
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    return accuracy, precision, recall, f1, loss_fn(y, p)


lr = 0.05
epochs = 30
batch_size = 32

n = len(X_train)
w = np.zeros(X_train.shape[1])

for epoch in range(1, epochs + 1):
    order = np.random.permutation(n)
    for start in range(0, n, batch_size):
        batch = order[start:start + batch_size]
        g = gradient(X_train[batch], y_train[batch], w)
        w = w - lr * g

    if epoch % 5 == 0 or epoch == 1:
        print(f"epoch {epoch:2d}  train loss = {loss_fn(y_train, sigmoid(X_train @ w)):.4f}")

acc, prec, rec, f1, loss = metrics(y_test, sigmoid(X_test @ w))
print("\nTest set results (mini-batch GD):")
print(f"Accuracy : {acc:.4f}")
print(f"Precision: {prec:.4f}")
print(f"Recall   : {rec:.4f}")
print(f"F1       : {f1:.4f}")
print(f"Loss     : {loss:.4f}")
